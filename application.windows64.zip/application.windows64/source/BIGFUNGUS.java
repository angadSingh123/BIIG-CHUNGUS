import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class BIGFUNGUS extends PApplet {

handler handler = new handler();
camera camera = new camera(0, 0);
float rotY = 0.5f;
Texture tex;

public void setup() {
   
  rectMode(CORNER);
  levelLoader(1);
  //tex = new Texture();
}



public void draw() {  

  myKeyPressed();

  handler.tick();

  camera.tick(handler.obj.get(0));

  translate(camera.getX(), camera.getY());

  handler.updateGraphics();
  rotY += 0.005f;

  pushMatrix();
  //rotateY(rotY);

  for (int i =0; i < 50; i+= 5) {    
    translate(i*25, 50);    
    pushMatrix();

    rotate(-rotY);

    box(50);

    popMatrix();
  }
  
  translate(0, 0);
  popMatrix();


  translate(-camera.getX(), -camera.getY());
}

public void myKeyPressed() {
  if (keyPressed) {
    if (key == 'd') {    

      handler.obj.get(0).velX = VELX;
      handler.obj.get(0).facing = RIGHT;
    } else if (key == 'a') {    

      handler.obj.get(0).facing = LEFT;
      handler.obj.get(0).velX = -VELX;
    } else if (key == 'w' && !handler.obj.get(0).jumping) {    
      handler.obj.get(0).jumping = true;
      handler.obj.get(0).velY = -MULT * VELY;
    }
  } else {
    handler.obj.get(0).velX = 0;
  }
}
public class Animation {
  
  int speed, frames, index, count;
  
  PImage [] images;
  PImage currImg;
  
      public Animation(int speed, PImage... args) {

        this.speed = speed;

        images = new PImage[args.length];

        for (int i = 0; i < args.length; i++) {

            images[i] = args[i];

        }
        
        frames = args.length;

    }

    
    
    public void runAnimation() {
        index++;
        if (index > speed) {

            index = 0;
            nextFrame();
        }

    }

    public void nextFrame() {

      
      
        for (int i = 0; i < frames; i++) {
            if (count == i) {
                currImg = images[i];
            }
        }

        count++;

        if (count > frames) {
            count = 0;

        }

    }

    public void drawAnimation( int x, int y) {

        image(currImg, x, y ); 
      
    }
      
}
 final int offset = 250;
 class camera {

   float x, y; 

  public camera(float x, float y) {
    this.x = x;
    this.y = y;
  }

  public void tick(gameObject Player) {

    this.x = -Player.x + offset;
  }

  public  void setX(float getX) { 
    camera.x = getX;
  }

  public  void setY(float getY) { 
    camera.y = getY;
  }

  public  float getX() {
    return camera.x;
  }

  public  float getY() {
    return camera.y;
  }
}
class collRect {

  int x, y, bwidth, bheight;

  collRect(int myX, int myY, int myWidth, int myHeight) {    
     this.x = myX;
     this.y = myY;
     this.bwidth = myWidth;
     this.bheight = myHeight;
  }

  public float getX() {
    return this.x;
  };

  public float getY() {
    return this.y;
  };

  public int getWidth() {
    return this.bwidth;
  }

  public int getHeight() {
    return this.bheight;
  }

} 
final int PLAYER = 1;
final int ENEMY = 2;
final int BOSS = 3;
final int BLOCK = 4;
final int BULLET = 5; 
final int LEFT = 1;
final int RIGHT = 2;
final int MAX_SPEED = 100;
final float GRAVITY = 1.98f;
final int VELX = 5;
final int VELY = 5;
final int MULT = 5;
final int PLAYER_HEIGHT = 32;
final int PLAYER_WIDTH = 32;


protected PImage player_image, enemy_image, block_image, bullet_image;

abstract class gameObject {

  protected float type, x, y, z, HEALTH, velX, velY, facing, h, w, angle;
  boolean jumping = !true, falling = !true, rotating = !true;  


  gameObject(int x, int y, int type) {
    this.x = x;
    this.y = y;
    this.type = type;
    switch(type) {
    case 1: 
      this.HEALTH = 100; 
      break;
    case 2: 
      this.HEALTH = 50;  
      break;
    case 3: 
      this.HEALTH = 200; 
      break;
    case 4: 
      break;
    case 5: 
      break;
    }
  }

  public abstract void render();

  public abstract void tick();

  public void setPosx(float x) {
    this.x = x;
  }

  public void setPosy(float y) {
    this.y = y;
  }

  public void setVelx(float velx) {
    this.velX = velx;
  } 


  public void setVely(float vely) {
    this.velY = vely;
  }

  public void setHealth(float x) {
    this.HEALTH = x;
  }   

  public float getY() {
    return this.y;
  }

  public float getX() {
    return this.x;
  }

  public float getHeight() {
    return this.h;
  }

  public abstract collRect getBoundsRight();
  public abstract collRect getBoundsLeft();
  public abstract collRect getBoundsTop();
  public abstract collRect getBoundsBottom();
}


 class handler {
  public ArrayList<gameObject> obj = new ArrayList(); 
 
  public void add(gameObject obj1) {
    obj.add(obj1);
  }

  public void tick()
  {
    background(0);
    for (gameObject gui : obj) {            
      gui.tick();
    }
  }

  public void updateGraphics() {    
    background(255);
    for (gameObject gui : obj) {                       
      gui.render();
    }
  }
}
final int tileSpecs = 32;

public void levelLoader(int level) {

  PImage level1, level2, image = null;
  //bufferedImageLoader loader = new bufferedImageLoader();

  switch(level) {

  case 1: 
    {
      level1 =loadImage("/res.png");
      image = level1;
      break;
    }
  case 2: 
    {
      level2 = loadImage("");
      image = level2;
      break;
    }

  default:
    {
      println("AN ERROR OCCURRED WHILE LOADING LEVEL IMAGES, CHECK LEVEL INPUT");
    }
  }

  if  (image != null) {
    int h = image.height;
    int w = image.width;
    int pixel = 0, red = 0, green = 0, blue = 0;


    image.loadPixels();

    for (int i = 0; i < w; i++) {
      for (int j = 0; j < h; j++) {    
        pixel = image.pixels[j*w + i];
        red  = (pixel >> 16) & 0xff;
        green = (pixel >> 8) & 0xff;
        blue = (pixel) & 0xff;
       
        
        if (red == 255 && green == 106 && blue == 0) {
          handler.add(new platform(i * tileSpecs, j *tileSpecs ));
        }
        
        else if (red == 0 && green == 255 && blue == 255) {
          gameObject temp = handler.obj.get(0);
          handler.obj.set(0,new player(i*tileSpecs, j*tileSpecs, this.handler.obj ));
          handler.add(temp);
        }
        
        
      }
    }
  }
}
public class platform extends gameObject {

  public platform(int x,int y) {
    super(x, y, BLOCK);
    this.x = x;
    this.y = y;
    this.w = 32;
    this.h = 32;
  }

  public collRect getBoundsRight() {
    return null;
  }
  public collRect getBoundsLeft() {
    return null;
  }
  public collRect getBoundsTop() {
    return new collRect((int)this.x,(int) this.y, (int)this.w, (int)this.h);
  }
  public collRect getBoundsBottom() {
    return null;
  }

  public void render() {    
    rect(this.x,this.y, this.w, this.h);
  }

  public void collision() {
  }

  public void tick() {    
  }   
  
}

class player extends gameObject {

  ArrayList <gameObject> handler;

 // public Animation right  = new Animation(1, tex.player_list.get(0));
  

  player(int x, int y, ArrayList list) {   
    super(x, y, PLAYER);
    this.handler = list; 
    this.falling = true;    

    this.w = PLAYER_WIDTH;
    this.h = PLAYER_HEIGHT;
  }

  public collRect getBoundsRight() {
    return new collRect((int) this.x + PLAYER_WIDTH - 5, (int) this.y, 5, (int) this.h);
  }
  public collRect getBoundsLeft() {
    return new collRect((int) this.x, (int) this.y, (int) 5, (int) this.h);
  }
  public collRect getBoundsTop() {
    return new collRect((int) this.x + 5, (int) this.y - 10, (int) this.w - 10, 10);
  }
  public collRect getBoundsBottom() {
    return new collRect((int) this.x, (int) this.y + PLAYER_HEIGHT, (int) this.w, 5);
  }

  public void tick() {
    this.x += this.velX;
    this.y += this.velY;

    if (jumping || falling) {
      this.velY += GRAVITY;

      if (velY > MAX_SPEED) {
        velY = MAX_SPEED;
      }
    }

    //right.runAnimation();
    collision();
  }

  public void render() {

    stroke(0);
    rect(this.x, this.y, this.w, this.h);    
    // right.drawAnimation((int)x, (int)y);
  }


  public void collision() {

    gameObject temp;  

    for (int i = 0; i < this.handler.size(); i++) {

      for (int j = 1; j < this.handler.size(); j++) {

        temp = this.handler.get(i);
        intersects(temp);
      }
    }
  }

  public void intersects(gameObject object) {

    collRect r = object.getBoundsTop();



    switch((int) object.type) {



    case BLOCK: 

      collRect myRect;

      myRect = this.getBoundsTop(); 

      if (r.x < myRect.x + myRect.bwidth &&
        r.x + r.bwidth > myRect.x &&
        r.y < myRect.y + myRect.bheight &&
        r.y + r.bheight > myRect.y) {

        velY = 0;
        this.y = object.y + 0.67f * PLAYER_HEIGHT;
      } else {
        falling  = true;
      }

      myRect = this.getBoundsBottom();                

      if ( r.x < myRect.x + myRect.bwidth &&
        r.x + r.bwidth > myRect.x &&
        r.y < myRect.y + myRect.bheight &&
        r.y + r.bheight > myRect.y) {

        this.jumping = false;
        falling= false;
        this.y = object.getY() - PLAYER_HEIGHT - 5;        
        this.velY = 0;
      } 
      myRect = this.getBoundsLeft(); 

      if (r.x < myRect.x + myRect.bwidth &&
        r.x + r.bwidth > myRect.x &&
        r.y < myRect.y + myRect.bheight &&
        r.y + r.bheight > myRect.y) {

        velX = 0;
        x = object.getX() + object.w;
      } else {
        falling = true;
      }


      myRect = this.getBoundsRight(); 

      if (r.x < myRect.x + myRect.bwidth &&
        r.x + r.bwidth > myRect.x &&
        r.y < myRect.y + myRect.bheight &&
        r.y + r.bheight > myRect.y) {

        velX = 0;
        x = object.getX() - object.w;
      }



      break;
    }
  }
}






//rect( (float) getBoundsBottom().x, (float) getBoundsBottom().y, getBoundsBottom().getWidth(), getBoundsBottom().getHeight());
//rect( (float) getBoundsTop().x, (float) getBoundsTop().y, getBoundsTop().getWidth(), getBoundsTop().getHeight());
//rect( (float) getBoundsLeft().x, (float) getBoundsLeft().y, getBoundsLeft().getWidth(), getBoundsLeft().getHeight());
//rect( (float) getBoundsRight().x, (float) getBoundsRight().y, getBoundsRight().getWidth(), getBoundsRight().getHeight());
//println(this.x + " " +this.y + " " + this.w + " " + this.h + " player" + mouseX + " "  +mouseY);
//println("col " + (tempRect.getY() + tempRect.getHeight()) + " " + object.getBoundsTop().getY());
public class spriteSheet{

  private PImage image;
    
  public spriteSheet(PImage image){
  
    this.image = image;
    
  }

public PImage grabImage(int col, int row, int myWidth, int myHeight){    
    PImage img = image.get((col*myWidth) - myWidth, (row*myHeight) - myHeight, myWidth, myHeight);
    return img;  
  }


}
public class Texture {

  private spriteSheet ps;

  //public PImage block_sheet = null;
  public PImage player_sheet = null;

  //public ArrayList <PImage> block_list = new ArrayList <PImage>();
  public ArrayList <PImage> player_list = new ArrayList <PImage>();

  public Texture() {  

    player_sheet = loadImage("/ps.png");
    //println("loade");
    //bs = new spriteSheet(block_sheet);
    ps = new spriteSheet(player_sheet);
    
    getTexture();
    
  }
  
  public void getTexture(){
  
   // block_list.add(bs.grabImage(0,0 ,32,32));  
    player_list.add(ps.grabImage(0,1,32, 64));    
    println("added" + player_list.toString());
    player_list.add(ps.grabImage(1,1,32, 64));   
    player_list.add(ps.grabImage(2,1,32, 64));
  
  }
  
}
  public void settings() {  size(849, 480, P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "BIGFUNGUS" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
